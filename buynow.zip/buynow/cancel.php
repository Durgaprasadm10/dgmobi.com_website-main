<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Order Cancelled | Landstar</title>
    <style>
        body {
            font-family: Helvetica, Arial, sans-serif;
        }
    </style>
</head>
<body>
    <center>
        <h1>Your order has been cancelled.</h1>
        <p>Back to <a href='landstar-dgmobi_buy_now.php'>Home</a></p>
    </center>
</body>
</html>