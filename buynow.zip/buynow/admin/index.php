<?php


echo "Access denied";
