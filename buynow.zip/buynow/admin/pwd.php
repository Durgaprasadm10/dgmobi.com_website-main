<?php

echo password_hash("Sridevi@123", PASSWORD_DEFAULT);
echo "\n";

echo password_hash("Rakesh@123", PASSWORD_DEFAULT);
